
import React, { useState } from 'react';
import { extractClinicData } from '../services/geminiService';
import { ClinicData } from '../types';

interface ModernizerModalProps {
  onUpdate: (data: ClinicData) => void;
  onClose: () => void;
}

const ModernizerModal: React.FC<ModernizerModalProps> = ({ onUpdate, onClose }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleModernize = async () => {
    if (!input.trim()) return;
    setLoading(true);
    const result = await extractClinicData(input);
    if (result) {
      onUpdate(result);
      onClose();
    } else {
      alert("Failed to extract data. Please try again with more detailed text.");
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300">
        <div className="p-6 bg-teal-600 text-white">
          <h2 className="text-2xl font-bold">PhysioFlow AI Modernizer</h2>
          <p className="text-teal-50 opacity-90 text-sm mt-1">
            Paste your old website text, brochures, or doctor bios. Our AI will redesign the site instantly.
          </p>
        </div>
        
        <div className="p-6">
          <textarea
            className="w-full h-48 p-4 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent resize-none text-slate-700 outline-none"
            placeholder="e.g. 'St. Jude's Physio Clinic. Established 1998. Dr. Robert Smith specializes in back pain... We have a private gym... Visit us at 45 Main St...'"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          
          <div className="flex justify-end gap-3 mt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 text-slate-600 hover:text-slate-800 font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleModernize}
              disabled={loading}
              className={`px-8 py-2 bg-teal-600 text-white rounded-lg font-bold shadow-lg shadow-teal-600/20 hover:bg-teal-700 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Redesigning...
                </>
              ) : 'Modernize Now'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModernizerModal;
