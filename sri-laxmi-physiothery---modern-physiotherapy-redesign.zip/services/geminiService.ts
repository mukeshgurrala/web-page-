
import { GoogleGenAI, Type } from "@google/genai";
import { ClinicData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const extractClinicData = async (rawInput: string): Promise<ClinicData | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Extract clinic details, credentials, and treatments from this text into a modern physiotherapy website structure. 
      Input text: ${rawInput}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            tagline: { type: Type.STRING },
            about: { type: Type.STRING },
            doctors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  credentials: { type: Type.STRING },
                  specialty: { type: Type.STRING },
                  bio: { type: Type.STRING },
                  image: { type: Type.STRING, description: "URL placeholder for images" }
                }
              }
            },
            treatments: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  icon: { type: Type.STRING }
                }
              }
            },
            facilities: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            contact: {
              type: Type.OBJECT,
              properties: {
                address: { type: Type.STRING },
                phone: { type: Type.STRING },
                email: { type: Type.STRING },
                openingHours: { type: Type.STRING }
              }
            }
          },
          required: ["name", "tagline", "doctors", "treatments", "contact"]
        }
      }
    });

    if (response.text) {
      const data = JSON.parse(response.text);
      // Ensure we have some default images if AI doesn't provide them
      data.doctors = data.doctors.map((doc: any, i: number) => ({
        ...doc,
        image: doc.image || `https://picsum.photos/seed/doctor-${i}/400/400`
      }));
      return data as ClinicData;
    }
    return null;
  } catch (error) {
    console.error("AI Extraction Error:", error);
    return null;
  }
};
